---
weight: 2
---

Unit tests can be ran on your local machine without the need for minikube.

## Run the tests

Open a terminal and run the following command:

``` bash
make test
```

The tests will run and the results will be printed to the terminal with a summary
at the end of the test run.
