---
weight: 1
---

The easiest way to install `cri-dockerd` is to use one of the pre-built binaries or
packages from the [releases page](https://github.com/Mirantis/cri-dockerd/releases).
There are numerous supported platforms and using a pre-built package will install
the binary and setup your system to run it as a service.
