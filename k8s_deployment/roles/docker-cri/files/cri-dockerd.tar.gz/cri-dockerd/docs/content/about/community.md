---
weight: 3
---

We can be found on the [Kubernetes Slack](https://communityinviter.com/apps/kubernetes/community) in the [`#cri-dockerd`](https://kubernetes.slack.com/messages/cri-dockerd) channel.


